
package interfaces;

/**
 *
 * @author Wh0
 */
public interface I_Registro {

   void insertarRegistro(String email, String password, String nombre, String apellido, String usurname);


    // Puedes agregar más métodos según las operaciones que desees realizar en la tabla "registro"
    
    // Por ejemplo:
    // Registro obtenerRegistroPorId(int id);
    // List<Registro> obtenerTodosLosRegistros();
    // void actualizarRegistro(int id, String nuevoEmail, String nuevaContraseña, ...);
    // void eliminarRegistro(int id);

}

    

